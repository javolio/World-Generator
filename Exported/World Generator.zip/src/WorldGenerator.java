public class WorldGenerator {
	
	public static void main(String[] args) {
		new InputWindow();
		/*Loader l=new Loader();
		World w=l.w;
		l.loadAll();
		w.mapWorld();
		JFrame frame=new JFrame("Map");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel panel=new JPanel();
		frame.setContentPane(panel);
		panel.setLayout(new BorderLayout());
		SwitchablePanel p=new SwitchablePanel(w);
		panel.add(p,BorderLayout.NORTH);
		panel.add(new ButtonPanel(p,w),BorderLayout.SOUTH);
		frame.pack();
		frame.setVisible(true);*/
	}
	
}
